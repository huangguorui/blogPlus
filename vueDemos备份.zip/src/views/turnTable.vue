<template>
  <div>
    zhuan
  </div>
</template>
<script>
export default {
  name: 'trueTable',
  data () {
    return {

    }
  }
}
</script>

