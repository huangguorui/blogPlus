<style lang="scss" scoped>
.left-game {
  width: 10%;
  height: 300px;
  position: fixed;
  left: 10px;
  top: 30%;
  border: 1px solid red;
}
ul > li {
  padding: 3%;
  block-size: border-box;
  cursor: pointer;
}
.container {
  box-sizing: border-box;
  border: 1px solid #ccc;
  height: 700px;
  margin: 3% auto;
}
</style>

<template>
  <div>
    <div class="left-game">
      <ul>
        <li>12312312</li>
        <li>12312312</li>
        <li>12312312</li>
        <li>12312312</li>
      </ul>
    </div>
    <div class="container">

    </div>
  </div>
</template>
<script>
export default {
  data () {
    return {

    }
  }
}
</script>

